# jopbayes
Code and data for the Journal of Phonetics article entitled Bayesian data analysis in the phonetic sciences: A tutorial introduction

Please see here for the current version: https://osf.io/g4zpv/. This github repo is not the current version any more. 
